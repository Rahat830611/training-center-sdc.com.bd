<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Auth;


/*

| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great! (H)
|
*/
/*
|--------------------------------------------------------------------------
| FrontEnd Section
|--------------------------------------------------------------------------
|
*/
Route::get('/clear-cache', function() {
   Artisan::call('cache:clear');
   Artisan::call('route:cache');
   Artisan::call('config:cache');
   Artisan::call('view:clear');
   return "Cache Cleared";
});


Route::get('/','FrontendController@index');
Route::get('/skill-training','FrontendController@gallery');
Route::get('/award-certifications','FrontendController@award');
Route::get('/contact-us','FrontendController@contactus');
Route::get('/privacy-policy','FrontendController@privacy');
Route::get('/terms','FrontendController@termss');
Route::get('/contact_us/{id}','FrontendController@contact_us');
Route::get('/about-us','FrontendController@aboutus')->name('about-us');
Route::get('/news','FrontendController@news');
Route::get('/candidate-service','FrontendController@candidate');
Route::get('/category_products/{id}','FrontendController@category_products');
Route::get('/course-details/{id}','FrontendController@course_details');
Route::post('/send_message','FrontendController@send_message');

Route::get('/blog','FrontendController@blog');
// Route::get('blog/{type}', 'FrontendController@blog')->name('blog.type');
Route::get('/services','FrontendController@services')->name('services');
Route::get('/career', 'FrontendController@career')->name('career');
Route::get('/hot-jobs', 'FrontendController@notice')->name('notice');
Route::get('/blog_details/{id}','FrontendController@blog_details');
Route::get('/download', 'FrontendController@downloadreport');
Route::post('/load_info', 'FrontendController@load_info')->name('loadinfo');
Route::get('/download-certificate', 'FrontendController@downloadcertificate')->name('downloadcertiview');
Route::post('/load_certificate_info', 'FrontendController@load_certificate')->name('loadcerinfo');
Route::get('download-certificates/{id}', 'FrontendController@downloadcerti')->name('downloadcerti');

//terms & condition refund return , privacy policy
// Route::get('/terms-condition','FrontendController@terms');
// Route::get('/privacy-policy','FrontendController@policy');
// Route::get('/refund-retuns','FrontendController@retunss');

// Route::get('/', function () {
//     return view('welcome');
// });
Route::get('apply-online', 'FrontendController@onlineapply');
Route::get('trade-registration/{id}', 'FrontendController@traderegistration');
Route::post('store-info', 'FrontendController@store_trade');
Auth::routes(['verify' => true, 'register' =>false]);
// Auth::routes();



/*
|--------------------------------------------------------------------------
| Backend Section
|--------------------------------------------------------------------------
|
*/
Route::get('/home','HomeController@index')->name('home');
Route::get('findCityWithStateID/{id}','Admin\ChildCategoryController@findCityWithStateID');
Route::post('dynamic_dependent/fetch', 'Admin\ProductController@fetch')->name('dynamicdependent.fetch');
Route::prefix('admin')->group(function () {
    Route::group(['middleware' => ['auth']], function () {

// Logo Controller

Route::get('create/logo','Admin\LogoController@create')->name('create_logo');
Route::post('post/logo','Admin\LogoController@store')->name('create_post');
Route::get('logo/delete/{id}','Admin\LogoController@delete')->name('delete_post');
Route::get('logo/status/{id}','Admin\LogoController@status')->name('logo_status');
Route::post('update/logo','Admin\LogoController@edit')->name('logo_update');

// Slider Controller
Route::get('slider/create','Admin\SliderController@create')->name('create_slider');
Route::post('post/slider','Admin\SliderController@store')->name('post_slider');
Route::get('slider/status/{id}','Admin\SliderController@status')->name('slider_status');
Route::get('slider/delete/{id}','Admin\SliderController@delete')->name('slider_delete');
Route::post('update/slider','Admin\SliderController@edit')->name('slider_update');

// Category Controller

Route::get('category/create','Admin\CategoryController@create')->name('create_category');
Route::post('post/category','Admin\CategoryController@store')->name('post_category');
Route::get('category/status/{id}','Admin\CategoryController@status')->name('category_status');
Route::get('category/delete/{id}','Admin\CategoryController@delete')->name('category_delete');
Route::post('update/category','Admin\CategoryController@edit')->name('category_update');

// Sub Category Controller

Route::get('subcategory/create','Admin\SubcategoryController@create')->name('create_Subcategory');
Route::post('post/subcategory','Admin\SubcategoryController@store')->name('post_subcategory');
Route::get('subcategory/status/{id}','Admin\SubcategoryController@status')->name('subcategory_status');
Route::get('subcategory/delete/{id}','Admin\SubcategoryController@delete')->name('subcategory_delete');
Route::post('update/subcategory','Admin\SubcategoryController@edit')->name('subcategory_update');

// Child Category Controller

Route::get('childcategory/create','Admin\ChildCategoryController@create')->name('create_childcategory');
Route::post('post/childcategory','Admin\ChildCategoryController@store')->name('post_childcategory');
Route::get('childcategory/status/{id}','Admin\ChildCategoryController@status')->name('childcategory_status');
Route::get('childcategory/delete/{id}','Admin\ChildCategoryController@delete')->name('childcategory_delete');
Route::post('update/childcategory','Admin\ChildCategoryController@edit')->name('childcategory_update');


// Category Description Controller

Route::get('ca_desc/create','Admin\CategoryDescriptionController@create')->name('create_ca_desc');
Route::post('post/ca_desc','Admin\CategoryDescriptionController@store')->name('post_ca_desc');
Route::get('view/ca_desc','Admin\CategoryDescriptionController@view')->name('view_ca_desc');
Route::get('ca_desc/status/{id}','Admin\CategoryDescriptionController@status')->name('ca_desc_status');
Route::get('ca_desc/delete/{id}','Admin\CategoryDescriptionController@delete')->name('ca_desc_delete');
Route::get('ca_desc/edit/{id}','Admin\CategoryDescriptionController@show')->name('ca_desc_show');
Route::post('update/ca_desc','Admin\CategoryDescriptionController@edit')->name('ca_desc_update');

// Category slider Controller

Route::get('ca_slider/create','Admin\CategorySliderController@create')->name('create_ca_slider');
Route::post('post/ca_slider','Admin\CategorySliderController@store')->name('post_ca_slider');
Route::get('view/ca_slider','Admin\CategorySliderController@view')->name('view_ca_slider');
Route::get('ca_slider/status/{id}','Admin\CategorySliderController@status')->name('ca_slider_status');
Route::get('ca_slider/delete/{id}','Admin\CategorySliderController@delete')->name('ca_slider_delete');
Route::get('ca_slider/edit/{id}','Admin\CategorySliderController@show')->name('ca_slider_show');
Route::post('update/ca_slider','Admin\CategorySliderController@edit')->name('ca_slider_update');

// About Us Controller

Route::get('aboutus/create','Admin\AboutusController@create')->name('create_aboutus');
Route::get('aboutus/view','Admin\AboutusController@view')->name('view_aboutus');
Route::post('post/aboutus','Admin\AboutusController@store')->name('post_aboutus');
Route::post('update/aboutus','Admin\AboutusController@edit')->name('aboutus_update');
Route::get('admin/aboutus/show/{id}','Admin\AboutusController@show');

// Message Controller
// Route::get('message/create','Admin\AboutusController@message_create')->name('create_message');
Route::post('post/message','Admin\AboutusController@message_store')->name('post_message');
Route::get('message/view','Admin\AboutusController@message_view')->name('view_message');
Route::get('admin/message/show/{id}','Admin\AboutusController@message_edit');
Route::post('admin/message/update','Admin\AboutusController@message_update');


// Product Controller
// Route::get('product/create', 'Admin\ProductController@create')->name('create_product');
Route::post('post/product', 'Admin\ProductController@store')->name('post_product');
Route::get('product/status/{id}', 'Admin\ProductController@status')->name('product_status');
Route::get('product/delete/{id}', 'Admin\ProductController@delete')->name('product_delete');
Route::get('product/edit/{id}', 'Admin\ProductController@show')->name('product_edit');
Route::post('update/product', 'Admin\ProductController@edit')->name('product_update');
Route::get('get-state-list/{id}', 'Admin\ProductController@getStateList');
Route::get('get-city-list/{id}', 'Admin\ProductController@getCityList');

// Header Controller

Route::get('header/create','Admin\HeaderController@create')->name('create_header');
Route::post('post/header','Admin\HeaderController@store')->name('post_header');
Route::get('view/header','Admin\HeaderController@view')->name('view_header');
Route::get('header/status/{id}','Admin\HeaderController@status')->name('header_status');
Route::get('header/delete/{id}','Admin\HeaderController@delete')->name('header_delete');
Route::post('update/header','Admin\HeaderController@edit')->name('header_update');

// Footer Controller

Route::get('footer/create','Admin\FooterController@create')->name('create_footer');
Route::post('post/footer','Admin\FooterController@store')->name('post_footer');
Route::get('view/footer','Admin\FooterController@view')->name('view_footer');
Route::get('footer/status/{id}','Admin\FooterController@status')->name('footer_status');
Route::get('footer/delete/{id}','Admin\FooterController@delete')->name('footer_delete');
Route::post('update/footer','Admin\FooterController@edit')->name('footer_update');

// Page Controller

Route::get('page/create','Admin\PageController@create')->name('create_page');
Route::post('post/page','Admin\PageController@store')->name('post_page');
Route::get('view/page','Admin\PageController@view')->name('view_page');
Route::get('page/show/{id}','Admin\PageController@show')->name('page_show');
Route::get('page/status/{id}','Admin\PageController@status')->name('page_status');
Route::get('page/delete/{id}','Admin\PageController@delete')->name('page_delete');
Route::post('update/page','Admin\PageController@edit')->name('page_update');


// Team Controller

// Route::get('team/create','Admin\OurTeamController@create')->name('create_team');
Route::post('post/team','Admin\OurTeamController@store')->name('post_team');
Route::get('view/team','Admin\OurTeamController@view')->name('view_team');
Route::get('team/status/{id}','Admin\OurTeamController@status')->name('team_status');
Route::get('team/delete/{id}','Admin\OurTeamController@delete')->name('team_delete');
Route::post('update/team','Admin\OurTeamController@edit')->name('team_update');

// Blog Controller

Route::get('blog/create','Admin\BlogController@create')->name('create_blog');
Route::post('post/blog','Admin\BlogController@store')->name('post_blog');
Route::get('view/blog','Admin\BlogController@view')->name('view_blog');
Route::get('blog/status/{id}','Admin\BlogController@status')->name('blog_status');
Route::get('blog/delete/{id}','Admin\BlogController@delete')->name('blog_delete');
Route::get('blog/edit/{id}','Admin\BlogController@show')->name('blog_show');
Route::post('update/blog','Admin\BlogController@edit')->name('blog_update');

// Gallery Controller

Route::get('gallery/create','Admin\GalleryController@create')->name('create_gallery');
Route::post('post/gallery','Admin\GalleryController@store')->name('post_gallery');
Route::get('view/gallery','Admin\GalleryController@view')->name('view_gallery');
Route::get('view/video','Admin\GalleryController@video')->name('video_gallery');
Route::get('gallery/status/{id}','Admin\GalleryController@status')->name('gallery_status');
Route::get('gallery/delete/{id}','Admin\GalleryController@delete')->name('gallery_delete');
Route::post('update/gallery/{id}','Admin\GalleryController@edit')->name('gallery_update');


// Notice Controller

Route::get('notice/create','Admin\NoticeController@create')->name('create_notice');
Route::post('post/notice','Admin\NoticeController@store')->name('post_notice');
Route::get('notice/status/{id}','Admin\NoticeController@status')->name('notice_status');
Route::get('notice/delete/{id}','Admin\NoticeController@delete')->name('notice_delete');
Route::post('update/notice/{id}','Admin\NoticeController@edit')->name('notice_update');

// Footer Bottom Controller

Route::get('footer_bottom/create','Admin\FooterBottomController@create')->name('create_footer_bottom');
Route::post('post/footer_bottom','Admin\FooterBottomController@store')->name('post_footer_bottom');
Route::get('view/footer_bottom','Admin\FooterBottomController@view')->name('view_footer_bottom');
Route::get('footer_bottom/status/{id}','Admin\FooterBottomController@status')->name('footer_bottom_status');
Route::get('footer_bottom/delete/{id}','Admin\FooterBottomController@delete')->name('footer_bottom_delete');
Route::post('update/footer_bottom','Admin\FooterBottomController@edit')->name('footer_bottom_update');

// Setting Header
Route::get('setting/header','Setting\HeaderController@index');
Route::post('setting/header/post','Setting\HeaderController@post');
Route::get('setting/header/status/{id}','Setting\HeaderController@status');

// Setting Slider
Route::get('setting/slider','Setting\SliderController@index');
Route::post('setting/slider/post','Setting\SliderController@post');
Route::get('setting/slider/status/{id}','Setting\SliderController@status');

// Setting Footer
Route::get('setting/footer','Setting\FooterController@index');
Route::post('setting/footer/post','Setting\FooterController@post');
Route::get('setting/footer/status/{id}','Setting\FooterController@status');

// Setting Colors
Route::get('setting/color','Setting\ColorController@index');
Route::post('setting/color/post','Setting\ColorController@post');
Route::get('setting/color/status/{id}','Setting\ColorController@status');
Route::resource('medicalreports', 'Admin\MedicalReportController');
Route::resource('tradesinfo', 'Admin\TradeController');
Route::get('tradesinfoByDateInterval', 'Admin\TradeController@tradesinfoByDateInterval')->name('tradesinfoByDateInterval');
Route::get('tradesinfoByDate/{date}', 'Admin\TradeController@tradesinfoByDate')->name('tradesinfoByDate');
Route::get('downloaddata/{id}', 'Admin\TradeController@downloadview')->name('downloadfile');
Route::post('downloadinfo', 'Admin\TradeController@tradesinfoByuser')->name('downloadinfo');
});
});

